## Contributors

bootstrap-table is due to the excellent work of the following contributors:

<table>
<tr>
<th>Author</th>
<th>Github</th>
<th>Location</th>
<th>Blog</th>
<th>Commits</th>
</tr>

<tr>
<td><img src="https://avatars.githubusercontent.com/u/2117018?v=3" width="32" height="32"> <a href="mailto:wenzhixin2010@gmail.com">文翼</a></td>
<td><a href="https://github.com/wenzhixin">wenzhixin</a></td>
<td>Guangzhou, China</td>
<td><a href="http://wenzhixin.net.cn">http://wenzhixin.net.cn</a></td>
<td>608</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/4496763?v=3" width="32" height="32"> <a href="mailto:dennishernandezvargas@gmail.com">Dennis Hernández</a></td>
<td><a href="https://github.com/djhvscf">djhvscf</a></td>
<td>Costa Rica</td>
<td><a href="http://djhvscf.github.io/Blog/">http://djhvscf.github.io/Blog/</a></td>
<td>29</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/2921893?v=3" width="32" height="32"> <a href="mailto:ice50505050@hotmail.com">Kamonwat Sangudsub</a></td>
<td><a href="https://github.com/ice5050">ice5050</a></td>
<td>Chiang Mai, Thailand</td>
<td><a href="http://www.kamonwat.ninja">http://www.kamonwat.ninja</a></td>
<td>9</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/553292?v=3" width="32" height="32"> D0d0</td>
<td><a href="https://github.com/D0d0">D0d0</a></td>
<td></td>
<td></td>
<td>7</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/2520829?v=3" width="32" height="32"> Timmy72</td>
<td><a href="https://github.com/Timmy72">Timmy72</a></td>
<td></td>
<td></td>
<td>7</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/2130852?v=3" width="32" height="32"> kula1922</td>
<td><a href="https://github.com/kula1922">kula1922</a></td>
<td></td>
<td></td>
<td>3</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/6866443?v=3" width="32" height="32"> janborup</td>
<td><a href="https://github.com/janborup">janborup</a></td>
<td></td>
<td></td>
<td>3</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/8710090?v=3" width="32" height="32"> Joseph Reiter</td>
<td><a href="https://github.com/thx2001r">thx2001r</a></td>
<td>United States</td>
<td></td>
<td>3</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1455662?v=3" width="32" height="32"> arifemre</td>
<td><a href="https://github.com/arifemre">arifemre</a></td>
<td></td>
<td></td>
<td>3</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/5487021?v=3" width="32" height="32"> Julien Bisconti</td>
<td><a href="https://github.com/veggiemonk">veggiemonk</a></td>
<td>Belgium</td>
<td><a href="https://twitter.com/veggiemonk">https://twitter.com/veggiemonk</a></td>
<td>3</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1874318?v=3" width="32" height="32"> <a href="mailto:tristanlee85@gmail.com">Tristan Lee</a></td>
<td><a href="https://github.com/tristanlee85">tristanlee85</a></td>
<td></td>
<td></td>
<td>3</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/8644915?v=3" width="32" height="32"> @mcspx</td>
<td><a href="https://github.com/mcspx">mcspx</a></td>
<td></td>
<td></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1476232?v=3" width="32" height="32"> <a href="mailto:mikepenz@gmail.com">Mike Penz</a></td>
<td><a href="https://github.com/mikepenz">mikepenz</a></td>
<td>Freistadt</td>
<td><a href="http://mikepenz.com">http://mikepenz.com</a></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/775601?v=3" width="32" height="32"> <a href="mailto:muzical84@hotmail.com">Janet</a></td>
<td><a href="https://github.com/Muzical84">Muzical84</a></td>
<td>Midwest</td>
<td><a href="http://twitter.com/JesusFreak84">http://twitter.com/JesusFreak84</a></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/59292?v=3" width="32" height="32"> nikolas</td>
<td><a href="https://github.com/nikolas">nikolas</a></td>
<td>New York, NY</td>
<td></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/5313150?v=3" width="32" height="32"> Dunaevsky Maxim</td>
<td><a href="https://github.com/dunmaksim">dunmaksim</a></td>
<td>Russia, Lipetsk</td>
<td></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1710772?v=3" width="32" height="32"> cokert</td>
<td><a href="https://github.com/cokert">cokert</a></td>
<td></td>
<td></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/2326627?v=3" width="32" height="32"> burnspirit</td>
<td><a href="https://github.com/burnspirit">burnspirit</a></td>
<td></td>
<td></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/2863538?v=3" width="32" height="32"> azamshul</td>
<td><a href="https://github.com/azamshul">azamshul</a></td>
<td></td>
<td></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/9211672?v=3" width="32" height="32"> Bert Hankes</td>
<td><a href="https://github.com/BertHankes">BertHankes</a></td>
<td>Utrecht</td>
<td><a href="http://www.a2hankes.nl">http://www.a2hankes.nl</a></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/5970450?v=3" width="32" height="32"> <a href="mailto:davide.renzi@gmail.com">Davide Renzi</a></td>
<td><a href="https://github.com/didaxRedux">didaxRedux</a></td>
<td>Rome, IT</td>
<td><a href="http://www.pantomedia.it">http://www.pantomedia.it</a></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/8870312?v=3" width="32" height="32"> <a href="mailto:duc.pham@enclave.vn">Duc N. PHAM</a></td>
<td><a href="https://github.com/ducnpham">ducnpham</a></td>
<td></td>
<td></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/385731?v=3" width="32" height="32"> <a href="mailto:michael.schramm@gmail.com">Michael Schramm</a></td>
<td><a href="https://github.com/wodka">wodka</a></td>
<td>Vienna</td>
<td></td>
<td>2</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/9944172?v=3" width="32" height="32"> <a href="mailto:tidalf@tidalf.fr">Tidalf</a></td>
<td><a href="https://github.com/TidalfFR">TidalfFR</a></td>
<td>France</td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1202596?v=3" width="32" height="32"> <a href="mailto:github@sopamo.de">Paul Mohr</a></td>
<td><a href="https://github.com/Sopamo">Sopamo</a></td>
<td>Germany</td>
<td><a href="www.sopamo.de">www.sopamo.de</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1369261?v=3" width="32" height="32"> Tomislav Simić</td>
<td><a href="https://github.com/petougao">petougao</a></td>
<td>Serbia, Europe</td>
<td><a href="http://dadizajn.net">http://dadizajn.net</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/9339703?v=3" width="32" height="32"> JSON-OBJECT</td>
<td><a href="https://github.com/JSON-OBJECT">JSON-OBJECT</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/3691490?v=3" width="32" height="32"> Peter Dave Hello</td>
<td><a href="https://github.com/PeterDaveHello">PeterDaveHello</a></td>
<td>Taiwan ROC</td>
<td><a href="https://www.peterdavehello.org/">https://www.peterdavehello.org/</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1701102?v=3" width="32" height="32"> egcerqueira</td>
<td><a href="https://github.com/egcerqueira">egcerqueira</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/2017998?v=3" width="32" height="32"> <a href="mailto:jmello@hotmail.com.br">João Mello</a></td>
<td><a href="https://github.com/multiarts">multiarts</a></td>
<td>Salvador</td>
<td><a href="joao.winserv.net.br">joao.winserv.net.br</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/2442098?v=3" width="32" height="32"> ltcszk</td>
<td><a href="https://github.com/ltcszk">ltcszk</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/5148536?v=3" width="32" height="32"> Emin Şen</td>
<td><a href="https://github.com/emnsen">emnsen</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/4281333?v=3" width="32" height="32"> jmarceli</td>
<td><a href="https://github.com/jmarceli">jmarceli</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/7952803?v=3" width="32" height="32"> <a href="mailto:git@adtime.at">DominikAngerer</a></td>
<td><a href="https://github.com/DominikAngerer">DominikAngerer</a></td>
<td>Austria</td>
<td><a href="http://www.adtime.at">http://www.adtime.at</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/79682?v=3" width="32" height="32"> l0pez</td>
<td><a href="https://github.com/l0pez">l0pez</a></td>
<td>Poland, Poznań</td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/9149445?v=3" width="32" height="32"> gianndall</td>
<td><a href="https://github.com/gianndall">gianndall</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1460006?v=3" width="32" height="32"> Paul Cothenet</td>
<td><a href="https://github.com/pcothenet">pcothenet</a></td>
<td>Mountain View, CA</td>
<td><a href="http://attackwithnumbers.com">http://attackwithnumbers.com</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1542297?v=3" width="32" height="32"> <a href="mailto:mengyou658@163.com">mengyou</a></td>
<td><a href="https://github.com/mengyou658">mengyou658</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/5520402?v=3" width="32" height="32"> rml1997</td>
<td><a href="https://github.com/rml1997">rml1997</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/3645565?v=3" width="32" height="32"> <a href="mailto:github@coyle.dk">Jan Borup Coyle</a></td>
<td><a href="https://github.com/JanCoyle">JanCoyle</a></td>
<td>Odense, Denmark</td>
<td><a href="http://www.coyle.dk">http://www.coyle.dk</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/10198214?v=3" width="32" height="32"> f0u</td>
<td><a href="https://github.com/f0u">f0u</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/61626?v=3" width="32" height="32"> <a href="mailto:srcnckr@gmail.com">Sercan Çakır</a></td>
<td><a href="https://github.com/mayoz">mayoz</a></td>
<td>Turkey</td>
<td><a href="http://www.sercancakir.com">http://www.sercancakir.com</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/171167?v=3" width="32" height="32"> Michał Zagdan</td>
<td><a href="https://github.com/zergu">zergu</a></td>
<td></td>
<td><a href="http://code42.pl/">http://code42.pl/</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/128070?v=3" width="32" height="32"> <a href="mailto:smgladkovskiy@gmail.com">Sergey Gladkovskiy</a></td>
<td><a href="https://github.com/smgladkovskiy">smgladkovskiy</a></td>
<td>Russia/Moscow</td>
<td><a href="http://uniglad.ru">http://uniglad.ru</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/3030334?v=3" width="32" height="32"> Him You Ten</td>
<td><a href="https://github.com/himyouten">himyouten</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/971893?v=3" width="32" height="32"> odannyboy000</td>
<td><a href="https://github.com/odannyboy000">odannyboy000</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/5407898?v=3" width="32" height="32"> Malik Rizwan</td>
<td><a href="https://github.com/rams0b">rams0b</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/1829789?v=3" width="32" height="32"> yonjah</td>
<td><a href="https://github.com/yonjah">yonjah</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/8653173?v=3" width="32" height="32"> Cravid</td>
<td><a href="https://github.com/Cravid">Cravid</a></td>
<td></td>
<td></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/4995734?v=3" width="32" height="32"> <a href="mailto:info@nagygergely.eu">Gergely Nagy</a></td>
<td><a href="https://github.com/chpdesign">chpdesign</a></td>
<td>Hungary, Miskolc</td>
<td><a href="http://nagygergely.eu">http://nagygergely.eu</a></td>
<td>1</td>
<tr>
<tr>
<td><img src="https://avatars.githubusercontent.com/u/188236?v=3" width="32" height="32"> gnhaku</td>
<td><a href="https://github.com/gnhaku">gnhaku</a></td>
<td>Moscow, Russia</td>
<td><a href="http://gnhaku.me">http://gnhaku.me</a></td>
<td>1</td>
<tr>

</table>

Update date: 2015-02-02, created with https://github.com/wenzhixin/github-contributors