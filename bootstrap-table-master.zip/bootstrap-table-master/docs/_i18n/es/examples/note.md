**Note:** Todos los ejemplos están basados en [jsFiddle](http://jsfiddle.net/), usted puede agregar su ejemplo usando Edit on GitHub link.

---

